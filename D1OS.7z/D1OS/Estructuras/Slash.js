const { EmbedBuilder } = require("discord.js");//Requerimos los paquetes

module.exports = {
	name: "",//Nombre del comando
	description: "",//Descripción del comando

	async execute(client, interaction){

		interaction.reply({})
	}
}

