const { EmbedBuilder } = require("discord.js");

module.exports = {

    name: "decir",
    description: "Digo un mensaje por ti, en el canal que quieras",
    options: [
        {
            name: "texto",
            description: "Escribe el texto a decir",
            type: 3,
            required: true,
            minLenght: 2,
            maxLenght: 450
        },

        {
            name: "canal",
            description: "Escribe el canal donde quieres que diga el mensaje",
            type: 7,
            channelTypes: [0],
            required: false
        }
    ],

    async execute(client, interaction){

        const owner = "706684921623740527";  //id de los que tienen permiso para ejecutar el comando

        if(interaction.user.id !== owner){
            return interaction.reply({ content: "✖️ No tienes los permisos requeridos, para usar este comando" })
        }


        const canals = interaction.options.getChannel("canal") || interaction.channel;
        const texto = interaction.options.getString("texto");

        if ( canals ) {
            canals.send( ` ${texto} `),
            interaction.reply({ content: `✔️ Mensaje enviado en el canal ${canals}`, ephemeral: true });
        }else{
            canals.send( `  ${texto} `),
            interaction.reply({ content: `✔️ Mensaje enviado en el mismo canal  `, ephemeral: true });
        }
    }
}