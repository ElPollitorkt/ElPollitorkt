const { EmbedBuilder } = require("discord.js");//Requerimos los paquetes

module.exports = {
	name: "setimagen",//Nombre del comando
	description: "Ponga una imagen animada",//Descripción del comando
	options: [
	{
		name: "imagen",
		description: "Selecciona la imagen",
		type: 11,
		required: true
	}],

	async execute(client, interaction){

		const owner = "706684921623740527";
		if(interaction.user.id !== owner){
			return interaction.reply({ content: "No tienes los permisos requeridos, para usar este comando" })
		}

		const avatar = interaction.options.getAttachment("imagen")

		await client.user.setAvatar(avatar.url).catch(async err => {
		})

		interaction.reply({ content: "La imagen ha sido cargada con exito" })
	}
}

